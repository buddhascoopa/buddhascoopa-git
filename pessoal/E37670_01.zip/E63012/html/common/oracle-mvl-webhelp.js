/*
 * ------------------------------------------------------------
 * Copyright (c) 2013, 2017, Oracle and/or its affiliates. All rights reserved.
 * This software is the proprietary information of Oracle
 * All Rights Reserved.
 * ------------------------------------------------------------
 *
 * SVN revision information:
 * @version $Revision: 2967 $:
 * @date    $Date: 2014-12-08 18:33:36 +0000 (Mon, 08 Dec 2014) $:
 */

/*
 * Oracle simplified JavaScript functions for WebHelp
 */

/*
 * Code for Show/Hide TOC Element Updates
 */
function showHideTocUpdate() {
    var showHideButton = $("#showHideButton");
    var showHideButtonFooter = $("#showHideButtonFooter");
    var navheader = $("#navheader");
    var toc_content = $("#content .toc > *");
    var list_content = $("#content .list-of-examples,.list-of-figures,.list-of-tables");

    showHideButton.css("display","inline");
    showHideButtonFooter.css("display","inline");

    if (myLayout.state.west.isClosed) {
        showHideButton.removeClass('pointLeft').addClass('pointRight');
        showHideButton.attr("title", "Toggle Show/Hide Sidebar [access key: Left Arrow]");
        showHideButton.text("Show Sidebar");
        showHideButtonFooter.removeClass('pointLeft').addClass('pointRight');
        showHideButtonFooter.attr("title", "Show Sidebar");
        showHideButtonFooter.text("Show Sidebar");
        navheader.css("left","auto");
        toc_content.css("display","block");
        list_content.css("display","block");

    } else {
        showHideButton.removeClass('pointRight').addClass('pointLeft');
        showHideButton.attr("title", "Toggle Hide/Show Sidebar [access key: Left Arrow]");
        showHideButton.text("Hide Sidebar");
        showHideButtonFooter.removeClass('pointRight').addClass('pointLeft');
        showHideButtonFooter.attr("title", "Hide Sidebar");
        showHideButtonFooter.text("Hide Sidebar");
        navheader.css("left","125px");
        toc_content.css("display","none");
        list_content.css("display","none");
    }
}
