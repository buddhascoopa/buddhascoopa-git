su - oraclea -c "/home/operpcs/bkp_online.sh"
